<?php
// Privileged CRUD connection
$host = 'sql307.infinityfree.com';
$db = 'if0_42213725_perfume_store';
$user = 'if0_42213725';
$pass = 'VAsx2foRZJFsj0';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo_modifier = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // Display actual error for local development debugging
    die("Database connection failed. Please check the modifier configuration. Error: " . $e->getMessage());
}
?>